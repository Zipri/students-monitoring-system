import EllipsisText from './ellipsisText';
export { EllipsisText };
