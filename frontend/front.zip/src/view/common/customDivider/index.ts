import CustomDivider from './customDivider';

export { CustomDivider };
