import MainLayout from './main';

export { MainLayout };
