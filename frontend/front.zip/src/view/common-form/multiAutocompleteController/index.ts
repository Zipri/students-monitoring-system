import MultiAutocompleteController from './multiAutocompleteController';
export { MultiAutocompleteController };
