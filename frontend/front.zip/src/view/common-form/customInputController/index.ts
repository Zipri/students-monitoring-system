import InputController from './customInputController';
export { InputController };
