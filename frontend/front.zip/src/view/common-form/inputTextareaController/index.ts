import InputTextareaController from "./inputTextareaController";
export { InputTextareaController };
