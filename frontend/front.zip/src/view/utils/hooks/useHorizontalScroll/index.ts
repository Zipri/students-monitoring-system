import useHorizontalScroll from './useHorizontalScroll';

export { useHorizontalScroll };
