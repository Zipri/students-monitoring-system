import getBackendDate from './getBackendDate';

export { getBackendDate };
