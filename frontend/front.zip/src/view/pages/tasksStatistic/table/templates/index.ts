import TasksStatisticTableProjectTemplate from './project';
import TasksStatisticTableChipItemWithArray from './chipItemWithArray';
import TasksStatisticTableHeaderTemplate from './header';

export {
  TasksStatisticTableProjectTemplate,
  TasksStatisticTableChipItemWithArray,
  TasksStatisticTableHeaderTemplate,
};
