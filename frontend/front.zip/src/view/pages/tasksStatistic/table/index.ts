import TasksStatisticTable from './table';

export { TasksStatisticTable };
