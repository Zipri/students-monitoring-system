import UniSettings from './uniSettings';

export { UniSettings };
