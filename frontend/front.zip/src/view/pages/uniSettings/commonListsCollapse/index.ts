import UniSettingsCommonListsCollapse from './commonListsCollapse';

export { UniSettingsCommonListsCollapse };
