import UniSettingsStudentsCollapse from './studentsCollapse';

export { UniSettingsStudentsCollapse };
