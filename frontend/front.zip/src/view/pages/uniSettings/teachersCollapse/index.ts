import UniSettingsTeachersCollapse from './teachersCollapse';

export { UniSettingsTeachersCollapse };
