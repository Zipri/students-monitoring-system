import TimelineTasksPartStaticInfoPart from './staticInfoPart';

export { TimelineTasksPartStaticInfoPart };
