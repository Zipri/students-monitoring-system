import ProjectsTable from './table';

export { ProjectsTable };
