import TasksKanbanPart from './kanban';

export { TasksKanbanPart };
