import ProjectsStatistic from './projectsStatistic';

export { ProjectsStatistic };
