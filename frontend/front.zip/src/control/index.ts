import useStores from './hook';
import RootStoreProvider from './provider';

export { RootStoreProvider, useStores };
