import UniSettingsStore from './uniSettings';

export { UniSettingsStore };
