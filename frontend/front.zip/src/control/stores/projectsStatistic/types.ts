import { TProject, TProjectExtended } from 'model/api/projects/types';
import { TTask } from 'model/api/tasks/types';

export type ProjectStatistic = TProjectExtended;
