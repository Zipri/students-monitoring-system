import Toggle from './toggle';
import { IToggle } from './types';

export { Toggle, type IToggle };
