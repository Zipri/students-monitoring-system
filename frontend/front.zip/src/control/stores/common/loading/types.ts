export interface ILoading {
    value: boolean;
    start: () => void;
    stop: () => void;
}
