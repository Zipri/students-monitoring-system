import Loading from './loading';
import { ILoading } from './types';

export { Loading, type ILoading };
