import StoreManager from './storeManager';

export { StoreManager };
