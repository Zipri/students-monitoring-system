import CommentsApi from './comments';

export { CommentsApi };
