import { services } from '@services';

const LogicRoot = {
  services: services,
};

export default LogicRoot;
