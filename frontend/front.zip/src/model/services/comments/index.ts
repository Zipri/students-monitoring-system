import CommentsService from './comments';

export { CommentsService };
